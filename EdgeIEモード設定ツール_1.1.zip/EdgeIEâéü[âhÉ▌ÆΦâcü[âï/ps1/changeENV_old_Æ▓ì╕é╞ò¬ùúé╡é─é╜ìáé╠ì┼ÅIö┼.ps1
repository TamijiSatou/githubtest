﻿### 通知メッセージの表示
Add-Type -AssemblyName System.Windows.Forms;
## メッセージボックス関数
function Show-Msgbox([string]$Text = "message", `
                     [string]$Caption = "PowerShell", `
                     [System.Windows.Forms.MessageBoxButtons]$MessageBoxButtons = [System.Windows.Forms.MessageBoxButtons]::OK, `
                     [System.Windows.Forms.MessageBoxIcon]$MessageBoxIcon = [System.Windows.Forms.MessageBoxIcon]::Information, `
                     [System.Windows.Forms.MessageBoxDefaultButton]$MessageBoxDefaultButton = [System.Windows.Forms.MessageBoxDefaultButton]::Button1){
    [System.Windows.Forms.MessageBox]::Show($Text, $Caption, $MessageBoxButtons, $MessageBoxIcon,$MessageBoxDefaultButton)
}


### リターンコード定義
$rc_array = [Object[]]::new(30)
$rc = 0
## エラー判定関数
function Error-Judgment([int16]$arg_num){
	if ( $? -ne "true" ) {
		$rc_array[$arg_num] = $arg_num
		Write-Output "→異常終了" 
	} else {
		Write-Output "→正常終了"
	}
}


### カレントディレクトリ変更(実行元batファイルの場所へ)
$ScriptDir = Split-Path $MyInvocation.MyCommand.Path -Parent
cd $ScriptDir
cd ..


### 変数定義
## ログファイル定義
$logfile = "02_EdgeIEモード設定ツール.log"

## ポリシー格納先
$policydir = "$ENV:SystemRoot" + "\PolicyDefinitions"
$policydir_jp = "$ENV:SystemRoot" + "\PolicyDefinitions\ja-JP"

## IEモードサイトリスト格納先
$edgecnfdir = "$ENV:SystemDrive" + "\edge_iemode_config"

## Windowsスタートアップディレクトリ
$startupdir = "$ENV:ProgramData" + "\Microsoft\Windows\Start Menu\Programs\Startup"

## Windowsパブリックユーザドキュメントディレクトリ
$public_doc = "$ENV:SystemDrive" + "\Users\Public\Documents\"

## Windowsパブリックユーザデスクトップ
$public_desktop = "$ENV:SystemDrive" + "\Users\Public\Desktop\"

C:\Users\Public\Desktop


### ログ取得開始
Start-Transcript "02_EdgeIEモード設定ツール.log"


### 管理者権限チェック
Write-Output " " ; Write-Output "1.管理者権限で実行しているか確認"
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$bool_admin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (! $bool_admin) {
	Write-Output '→非管理者権限で実行のため終了'
	$DialogResult = Show-Msgbox `
	-Text "このツールは管理者権限で実行をお願いいたします。`r`n`「OK」をクリックすると終了します。" `
	-Caption "EdgeIEモード設定ツール"
	exit 1
}
Write-Output '→管理者権限で実行'


### 実行可否選択
Write-Output " " ; Write-Output "2.設定ツール実行可否選択（『OK』と『キャンセル』ボタン選択）"
$DialogResult = Show-Msgbox `
-Text "EdgeIEモードの設定を行います。`r`n`開始する場合は「OK」をクリックしてください。`r`n`終了する場合は「キャンセル」をクリックしてください。" `
-Caption "EdgeIEモード設定ツール" -MessageBoxButtons OKCancel -MessageBoxIcon Question

Switch ($DialogResult){
    {$_ -eq [System.Windows.Forms.DialogResult]::Cancel}{
        Write-Output "→キャンセル(Cancel)がクリックされました。"
        exit 0
    }
}
Write-Output "→OKがクリックされました。"


### InternetExplorer11有効可(Windowアーキテクチャ(32bit or 64bit)によってコマンド変化)
[string]$winarch = (Get-WmiObject Win32_OperatingSystem).OSArchitecture
[int16]$winarch = $winarch | % { $_.Split(" ")[0]}
if($winarch -eq 32) {
	$ie11feature = "Internet-Explorer-Optional-x86"
} else {
	$ie11feature = "Internet-Explorer-Optional-amd64"
}
Write-Output " " ; Write-Output "3.InternetExplorer11有効可"
dism /online /Enable-Feature /FeatureName:"$ie11feature" /NoRestart
Error-Judgment -arg_num 3


### 設定ファイルコピー
Write-Output " " ; Write-Output "4.Edge用ポリシーファイルコピー"
Copy-Item ".\files\MicrosoftEdgePolicyTemplates100\admx\msedge.admx" "$policydir\msedge.admx" -force
Error-Judgment -arg_num 4

Write-Output " " ; Write-Output "5.Edge用日本語ポリシーファイルコピー"
Copy-Item ".\files\MicrosoftEdgePolicyTemplates100\admx\ja-JP\msedge.adml" "$policydir_jp\msedge.adml" -force
Error-Judgment -arg_num 5

Write-Output " " ; Write-Output "6.EdgeIEモードサイトリストディレクトリ作成"
New-Item $edgecnfdir -ItemType Directory -force
Error-Judgment -arg_num 6

Write-Output " " ; Write-Output "7.EdgeIEモードサイトリストコピー"
Copy-Item ".\files\edge_iemode_config\sites.xml" $edgecnfdir\sites.xml -force
Error-Judgment -arg_num 7

Write-Output " " ; Write-Output "8.信頼済みサイト登録＆保護モード無効可スクリプトコピー"
Copy-Item ".\files\edgeiemode_zonemap2.vbs" "$startupdir\edgeiemode_zonemap2.vbs" -force
Error-Judgment -arg_num 8


### Edge用icoファイルコピー
Write-Output " " ; Write-Output "9.Edge用icoファイルコピー"
Copy-Item ".\files\jfsystem_link\jf_icofile" $public_doc -force -recurse
Error-Judgment -arg_num 9


### 組合端末用ショートカットファイルコピー(事務所端末向けはここを実行しないようにする)
if($winarch -eq 32) {
	$shortcutdir = ".\files\jfsystem_link\32bit_shortcut\*"
} else {
	$shortcutdir = ".\files\jfsystem_link\64bit_shortcut\*"
}
Copy-Item $shortcutdir $public_desktop -force -recurse
Error-Judgment -arg_num 10


### Edge設定
Write-Output " " ; Write-Output "13.Edge設定用レジストリキー追加"
New-Item -Path "registry::HKLM\SOFTWARE\Policies\Microsoft\Edge" -force
Error-Judgment -arg_num 13

Write-Output " " ; Write-Output "14.IEモード有効可(レジストリ)"
set-itemproperty -Path "registry::HKLM\SOFTWARE\Policies\Microsoft\Edge" -Name InternetExplorerIntegrationLevel -Type DWord -Value 1
Error-Judgment -arg_num 14

# Write-Output " " ; Write-Output "15.エンタープライズサイトリスト有効可(レジストリ)"
# set-itemproperty -Path "registry::HKLM\SOFTWARE\Policies\Microsoft\Edge" -Name EnterpriseModeSiteListManagerAllowed -Type DWord -Value 1 -force
# Error-Judgment -arg_num 15

Write-Output " " ; Write-Output "16.エンタープライズサイトリストの格納場所定義(レジストリ)"
set-itemproperty -Path "registry::HKLM\SOFTWARE\Policies\Microsoft\Edge" -Name InternetExplorerIntegrationSiteList -Type String -Value "$edgecnfdir\sites.xml" -force
Error-Judgment -arg_num 16

Write-Output " " ; Write-Output "17.IEモードページの表示を高さ35ピクセル広くする(デフォルトの差異＋アドレスバーが表示される分を追加)(レジストリ)"
set-itemproperty "registry::HKLM\Software\Policies\Microsoft\Edge" -Name "InternetExplorerIntegrationWindowOpenHeightAdjustment" -Type DWord -Value 35 -force
Error-Judgment -arg_num 17

Write-Output " " ; Write-Output "18.IEモードページの表示を幅10ピクセル広くする(デフォルトの差異分を追加)(レジストリ)"
set-itemproperty "registry::HKLM\Software\Policies\Microsoft\Edge" -Name "InternetExplorerIntegrationWindowOpenWidthAdjustment" -Type DWord -Value 10 -force
Error-Judgment -arg_num 18

Write-Output " " ; Write-Output "19.Edgeポップアップブロック設定用レジストリキー追加"
New-Item -Path "registry::HKLM\Software\Policies\Microsoft\Edge\PopupsAllowedForUrls" -force
Error-Judgment -arg_num 19

Write-Output " " ; Write-Output "20.ksr.localポップアップ許可(レジストリ)"
set-itemproperty "registry::HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Edge\PopupsAllowedForUrls" -Name "1" -Type String -Value "[*.]ksr.local" -force
Error-Judgment -arg_num 20

Write-Output " " ; Write-Output "21.kyosuiren.or.jpポップアップ許可(レジストリ)"
set-itemproperty "registry::HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Edge\PopupsAllowedForUrls" -Name "2" -Type String -Value "[*.]kyosuiren.or.jp" -force
Error-Judgment -arg_num 21

Write-Output " " ; Write-Output "22.certificateポップアップ許可(レジストリ)"
set-itemproperty "registry::HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Edge\PopupsAllowedForUrls" -Name "3" -Type String -Value "[*.]certificate" -force
Error-Judgment -arg_num 22


### エラー判定
Write-Output " " ; Write-Output "23.エラー判定"
for ($i=0; $i -lt $rc_array.Count; $i++){
	if ( $rc_array[$i] -ne $null ) {
		$err_msg = "処理番号「" + $rc_array[$i] + "」でエラーが発生しています。"
		Write-Output $err_msg
		$rc = 1
	}
}
if ( $rc -eq 0 ) {
	Write-Output "→EdgeIEモード設定が正常終了しました。"
} else {
	Write-Output "→EdgeIEモード設定で異常が発生しました。"
	Show-Msgbox -Text "EdgeIEモード設定で異常が発生しました。`r`n`「02_EdgeIEモード設定ツール.log」を担当者に送付してください。`r`n`「OK」をクリックすると終了します。" -Caption "EdgeIEモード設定ツール" -MessageBoxIcon Warning
	exit 1
}


### ログ取得終了
Stop-Transcript


### 正常終了メッセージと再起動（『OK』と『キャンセル』ボタン選択）
$DialogResult = Show-Msgbox `
-Text "EdgeIEモード設定が正常終了しました。端末の再起動をお願いします。`r`n`今すぐ再起動する場合は「OK」をクリックしてください。`r`n`後ほど再起動する場合は「キャンセル」をクリックしてください。" `
-Caption "EdgeIEモード設定ツール" -MessageBoxButtons OKCancel -MessageBoxIcon Question


Switch ($DialogResult){
    {$_ -eq [System.Windows.Forms.DialogResult]::Ok}{
        shutdown -r -t 0 -f
        exit 0
    }
}

Switch ($DialogResult){
    {$_ -eq [System.Windows.Forms.DialogResult]::Cancel}{
        Write-Output "再起動のキャンセル(Cancel)がクリックされました。"
        exit 0
    }
}

exit 0
