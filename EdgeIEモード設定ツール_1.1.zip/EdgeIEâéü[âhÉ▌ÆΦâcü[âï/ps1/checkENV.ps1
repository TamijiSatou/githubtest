﻿### ログファイル定義
$logfile = "01_EdgeIEモード調査ツール.log"


### 時刻表示
Get-Date > $logfile


### 通知メッセージの表示
Add-Type -AssemblyName System.Windows.Forms;


### メッセージボックス関数
function Show-Msgbox([string]$Text = "message", `
                     [string]$Caption = "PowerShell", `
                     [System.Windows.Forms.MessageBoxButtons]$MessageBoxButtons = [System.Windows.Forms.MessageBoxButtons]::OK, `
                     [System.Windows.Forms.MessageBoxIcon]$MessageBoxIcon = [System.Windows.Forms.MessageBoxIcon]::Information, `
                     [System.Windows.Forms.MessageBoxDefaultButton]$MessageBoxDefaultButton = [System.Windows.Forms.MessageBoxDefaultButton]::Button1){
    [System.Windows.Forms.MessageBox]::Show($Text, $Caption, $MessageBoxButtons, $MessageBoxIcon,$MessageBoxDefaultButton)
}


### 調査ツール実行可否選択（『OK』と『キャンセル』ボタン選択）
$DialogResult = Show-Msgbox `
-Text "EdgeIEモードが設定可能か調査を行います。`r`n`開始する場合は「OK」をやめる場合は「キャンセル」をクリックしてください。" `
-Caption "EdgeIEモード調査ツール" -MessageBoxButtons OKCancel -MessageBoxIcon Question

Switch ($DialogResult){
    {$_ -eq [System.Windows.Forms.DialogResult]::Cancel}{
        Write-Output "キャンセル(Cancel)がクリックされました。" >> $logfile
        exit 0
    }
}


### Windows10バージョン確認
[int16]$win10ver = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name CurrentMajorVersionNumber).CurrentMajorVersionNumber
[int16]$buildnum = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name CurrentBuildNumber).CurrentBuildNumber
Write-Output '↓実行端末のWindowsバージョン情報↓' >> $logfile
[System.Environment]::OSVersion.Version >> $logfile

## Windowアーキテクチャ確認(32bit or 64bit)
[string]$winarch = (Get-WmiObject Win32_OperatingSystem).OSArchitecture
Write-Output $winarch  >> $logfile

## Windows10メジャーバージョン確認
if ($win10ver -ne 10) {
	Write-Output 'Windows10メジャーバージョンチェック異常終了' >> $logfile
	$DialogResult = Show-Msgbox `
	-Text "この端末はEdgeIEモード対応端末ではありません。`r`n`Windows10の端末にて実施をお願いいたします。" `
	-Caption "EdgeIEモード調査ツール" -MessageBoxIcon Warning
	exit 1
	
## Windows10ビルド番号確認（19043未満はサポート外）
} elseif ($buildnum -lt 19043) {
	Write-Output 'Windows10ビルド番号チェック異常終了' >> $logfile
	$DialogResult = Show-Msgbox `
	-Text "この端末はEdgeIEモード対応端末ではありません。`r`n`WindowsUpdateで端末のアップデートをお願いいたします。" `
	-Caption "EdgeIEモード調査ツール" -MessageBoxIcon Warning
	exit 1
}


### InternetExplorer11インストール確認
$iereg = Get-ItemProperty "registry::HKLM\SOFTWARE\Microsoft\Internet Explorer"
$iever = $iereg.Version
Write-Output '↓実行端末のInternetExplorer11バージョン情報↓' >> $logfile
Write-Output $iereg >> $logfile

if ($iever -eq $null) {
	Write-Output 'InternetExplorer11インストールチェック異常終了' >> $logfile
	$DialogResult = Show-Msgbox `
	-Text "この端末にInternetExplorer11がインストールされていません。`r`n`インストールの実施をお願いいたします。" `
	-Caption "EdgeIEモード調査ツール" -MessageBoxIcon Warning
	exit 1
}


### Edgeインストール＆バージョン確認
[int16]$winarch = $winarch | % { $_.Split(" ")[0]}
if($winarch -eq 32) {
    $edgepath= $env:SystemDrive + "\Program Files\Microsoft\Edge\Application\msedge.exe"
} else {
    $edgepath= $env:SystemDrive + "\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
}

[int16]$edgever = (get-item ($edgepath)).VersionInfo.FileVersion | % { $_.Split(".")[0]}
Write-Output '↓実行端末のEdgeバージョン情報↓' >> $logfile
(get-item (get-item ($edgepath))).VersionInfo >> $logfile

## Edgeインストール確認
if($edgever -eq 0) {
	Write-Output 'Edgeインストールチェック異常終了' >> $logfile
	$DialogResult = Show-Msgbox `
	-Text "この端末にEdgeがインストールされていません。`r`n`手順書に沿ってEdgeのインストールをお願いいたします。" `
	-Caption "EdgeIEモード調査ツール" -MessageBoxIcon Warning
	exit 1

## Edgeバージョン確認（95未満はサポート外）
} elseif ($edgever -lt 95) {
	Write-Output 'Edgeバージョンチェック異常終了' >> $logfile
	$DialogResult = Show-Msgbox `
	-Text "この端末のEdgeはバージョンが「95」未満です。`r`n`手順書に沿ってEdgeのインストールをお願いいたします。" `
	-Caption "EdgeIEモード調査ツール" -MessageBoxIcon Warning
	exit 1
}

### 正常終了ダイアログ
Write-Output '調査が完了しました。この端末にEdgeIEモードの設定が可能です。' >> $logfile
$DialogResult = Show-Msgbox `
-Text "調査が完了しました。この端末にEdgeIEモードの設定が可能です。`r`n`手順書に沿ってEdgeIEモードの設定をお願いいたします。" `
-Caption "EdgeIEモード調査ツール"

Get-Date >> $logfile
exit 0

